import React from 'react'
import 'bootstrap/dist/css/bootstrap.min.css';
import './pagesstyle.css';
const Home = () => {
  return (
    <div className='home container w-100 vh-100'>
       
    </div>
  )
}

export default Home