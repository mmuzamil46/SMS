import React from 'react'
import 'bootstrap/dist/css/bootstrap.min.css';
const Student = () => {
  return (
    <div className='w-100 vh-100 d-flex justify-content-center align-items-center container'>
        <h1>students</h1>
    </div>
  )
}

export default Student